module Text.ParserCombinators.Poly
  ( module Text.ParserCombinators.Poly.Plain
  ) where

import Text.ParserCombinators.Poly.Plain
