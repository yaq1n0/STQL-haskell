## 1.13

- GHC-8.8 compatibility
- PolyParse has MonadFail as a superclass.

## 1.12.1

- GHC-8.6 compatibility
    - MonadFail instances
