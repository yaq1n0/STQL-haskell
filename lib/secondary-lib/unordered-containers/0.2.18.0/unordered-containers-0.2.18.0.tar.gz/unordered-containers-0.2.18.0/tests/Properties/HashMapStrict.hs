{-# LANGUAGE CPP #-}

#define STRICT

#include "HashMapLazy.hs"
