module AST where

data Term =
     STrue
     | SFalse
     deriving Show
