module NameSet (
    NameSet,
    module Data.IntSet
) where

import Data.IntSet

type NameSet = IntSet
