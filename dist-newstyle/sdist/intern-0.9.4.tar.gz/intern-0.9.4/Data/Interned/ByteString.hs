module Data.Interned.ByteString
  ( InternedByteString(internedByteStringId)
  ) where

import Data.Interned.Internal.ByteString

