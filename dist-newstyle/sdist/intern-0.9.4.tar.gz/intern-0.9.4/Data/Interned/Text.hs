module Data.Interned.Text
  ( InternedText(internedTextId)
  ) where

import Data.Interned.Internal.Text
