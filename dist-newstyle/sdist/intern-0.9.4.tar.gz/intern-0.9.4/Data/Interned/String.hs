module Data.Interned.String
  ( InternedString(internedStringId)
  ) where

import Data.Interned.Internal.String
